package com.traveller.airplanes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirplanesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirplanesApplication.class, args);
	}

}
