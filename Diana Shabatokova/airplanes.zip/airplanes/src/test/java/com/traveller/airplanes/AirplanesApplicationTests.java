package com.traveller.airplanes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirplanesApplicationTests {

	@Test
	void contextLoads() {
	}

}
